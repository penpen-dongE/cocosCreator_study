(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/02.Script/GameMain.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '464c9XVglpLkbSosRc7gwNi', 'GameMain', __filename);
// 02.Script/GameMain.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        imgMan: cc.Sprite,
        imgWoman: cc.Sprite
    },

    onLoad: function onLoad() {
        // 배경색 흰색으로 - 단순히 공부용
        cc.Camera.main.backgroundColor = cc.color(255, 255, 255);

        // 기본 zIndex 값은 0이다.
        cc.log(this.imgMan.node.zIndex);
        cc.log(this.imgWoman.node.zIndex);

        this.imgMan.node.zIndex = 1;
    }

    // update: function (dt) {},
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GameMain.js.map
        